#define USE_SIMPLE_DSP_BOARD

#include <vs1053.h>

#define USE_MIC 1 // define 1 for mic-in, 0 for line-in

#include <string.h>
#include <stdlib.h>

#define BLOCKSIZE 64 // amount of samples processed in one time
#define MY_SAMPLERATE 24000
#define DELAY_BUF_SZ 8192

#define DEPTH 2000   // [0...2047]  Depht effect
#define SPEED 20     // [0...1023]  LFO oscillator   
#define DELAY 8000   // [0...8100]  Delay of effect channel in samples
#define DECAY 28000  // [0...32000] Speed of attenuation of the effect
#define MIX   24000  // [0...32000] Amount of delay/effect channel on output

void InitAudioExample(u_int16 srInput,int useMicIn,u_int16 coreClock); // (see "init.c")
// Remember to never allocate buffers from stack space. So, if you
// allocate the space inside your function, never forget "static"!
static s_int16 __y delayBuffer[DELAY_BUF_SZ]; // delay line (buffer in Y memory)

// These are at addr 0x0800, 0x0801,...0x0804 musicPlayer.sciWrite(VS1053_REG_WRAMADDR, addr);
struct Effect {
	u_int16 depth;
	u_int16 speed;
	u_int16 delay;
	u_int16 decay;
	u_int16 mix;
};

struct Effect __x effect = {DEPTH, SPEED, DELAY, DECAY, MIX};

// Probably at address 0x086
s_int16 __x loopVar0 = 0;

// Probably at address 0x087
// Indicate button GPIO3 being pressed
s_int16 __x NoEffect = 0;

// Probably at address 0x088
s_int16 __x loopVar1 = 0;

// Probably at address 0x089
s_int16 __x loopVar2 = 0;


main(void) {

	s_int16 auxBuffer[2*BLOCKSIZE];     // auxiliary audio buffer
	s_int16 __y lineInBuf[2*BLOCKSIZE]; // line-in audio buffer
	s_int16 __y *bufptr = delayBuffer;
	s_int16 __y *flgptr = delayBuffer;
	s_int16 phase = 0;                  // this is the (accumulator) phase for the LFO
	s_int16 flangerSample = 0;
	u_int16 flangerPhase = 0;
	// parameters for the currently selected effect:
		
	// need to enable interrupts when executed as a plug-in
	Enable();
	// avoid being called again (when executed as a plug-in)	
	applAddr = NULL;
	
	effect.delay += (effect.depth/2)+1;       // depth/2 added to delay
	// initialize delay line with silence
	memsetY(delayBuffer, 0, DELAY_BUF_SZ);    // delayBuffer all = 0
	// disable interrupts during initialization
	Disable();
	// basic initialization phase in int.c
	InitAudioExample(MY_SAMPLERATE,USE_MIC,CORE_CLOCK_3X); // Check if can do CORE_CLOCK_4X 3.5X 4.5X 5X
	// adjust output samplerate
	// VS1053 has 18-bit stereo DAC. DAC samplerate can be adjusted by ROM function:
	// SetHardware(2, 48000U); Stereo, 48 kHz
	// Parameters for the function are number of output channels (1 or 2) and output sample
	// rate in Hz. Fine tuning for the DAC sample rate can be done with a 32-bit number.
	// The lower 16 bits are written to the register FREQCTLL and higher 4 bits to the register FREQCTLH.
	SetHardware(2/*stereo output*/,MY_SAMPLERATE/*DA sample rate*/);
	//
	USEX(INT_ENABLE)|=(1<<INT_EN_MODU)/*AD*/|(1<<INT_EN_DAC);
	// initialize audio_buffer read and write pointers
        //extern s_int16 __y audio buffer[]; 
        //volatile extern s_int16 __y * audio_wr_pointer;
        //volatile extern s_int16 __y * audio_rd_pointer;
        // To stop playing, just set the audio_rd_pointer to audio_wr_pointer so the audio buffer seems empty.
	audio_rd_pointer = audio_buffer;               // ROM defined output buffer
	audio_wr_pointer = audio_buffer + 2*BLOCKSIZE; // Two blocksize samples ahead

	// clear audio buffer (avoid unwanted noise in the beginning)
	memsetY(audio_buffer,0,AUDIO_BUFFER_SZ);

	// enable interrupts
	Enable();	
//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Main loop
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
	while (1) {


		if (StreamDiff() > BLOCKSIZE*2) { // x 2 because stereo => enough to process
			u_int16 i;
			s_int16 temp = 0;
			u_int32 fractDelay;
			__y s_int16 *lp = lineInBuf;
			s_int16 *sp = auxBuffer;
			//
			// read input samples (stereo, hence 2 x block size)
			//
			StreamBufferReadData(lineInBuf, 2*BLOCKSIZE);

                 	// process BLOCKSIZE samples at one go
			for (i = 0; i < BLOCKSIZE; i++) {
				// fractional delay part
				s_int16 flangerOut = (s_int16)(((s_int32)*flgptr * (65535U-flangerPhase)) >> 16);
				//
				// advance flgptr (and wrap the cyclic buffer)
				//
				if (flgptr >= delayBuffer+DELAY_BUF_SZ-1) {
					flgptr = delayBuffer;
                                        loopVar1 = 1;
				} else {
					flgptr++;
                                        loopVar1 = 0;
				}
				//
				flangerOut += (s_int16)(((s_int32)*flgptr * flangerPhase) >> 16);
			        ///////////////////////////////////////////////////////////
				// mix dry and effect and send to output (mix) 
                                ///////////////////////////////////////////////////////////
				*sp = (s_int16)(((s_int32)lp[0] * (32000U-effect.mix) + 
						(s_int32)flangerOut * effect.mix) >> 15);
                                ///////////////////////////////////////////////////////////
                                // add input sample to buffer with feedback (decay)
                                // 
                                ///////////////////////////////////////////////////////////
				*bufptr = (s_int16)(((s_int32)*sp++ * effect.decay + 
						(s_int32)lp[0] * (32000U-effect.decay)) >> 15);
				lp += 2;
				sp[0] = sp[-1]; // duplicate output to both channels
				sp++;
                                ///////////////////////////////////////////////////////////
				// advance bufptr (and wrap the cyclic buffer)
                                ///////////////////////////////////////////////////////////
				if (bufptr	>= delayBuffer+DELAY_BUF_SZ-1) {
					bufptr = delayBuffer;
                                        loopVar2 = 1;
				} else {
					bufptr++;
                                        loopVar2 = 0;
				}
			}

			phase += effect.speed; 
			{
			u_int32 tt = (u_int32)((u_int16)abs(phase)) * effect.depth;
			flangerSample = (u_int16)(tt >> 16);
			flangerPhase = (u_int16)tt;
			}
			
			flgptr = bufptr + flangerSample - effect.delay;
			if (flgptr < delayBuffer) {
				flgptr += DELAY_BUF_SZ;
                                loopVar0 = 1;
			} else loopVar0 = 0;
		
			AudioOutputSamples(auxBuffer, BLOCKSIZE);

		} 
		
	} // while(1)
	
	return 0;
   
}